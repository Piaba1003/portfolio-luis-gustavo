import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "#1a1a2e",
        surface: "#16213e",
        primary: "#e94560",
        "primary-hover": "#d13d56",
        "text-primary": "#ffffff",
        "text-secondary": "#a2a2bd",
        line: "rgba(233, 69, 96, 0.2)",
        input: "#1a1a2e",
        "input-border": "#2a2a4a",
      },
      fontFamily: {
        heading: ["var(--font-heading)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      letterSpacing: {
        tightish: "-0.01em",
      },
    },
  },
  plugins: [],
};

export default config;
